package com.example.foodorderback;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FoodOrderBackApplicationTests {

	@Test
	void contextLoads() {
	}

}
