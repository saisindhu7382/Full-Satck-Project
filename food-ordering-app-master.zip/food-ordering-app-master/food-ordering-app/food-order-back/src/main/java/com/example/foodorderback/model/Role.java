package com.example.foodorderback.model;

public enum Role {
	ADMIN, USER, EMPLOYEE
}
